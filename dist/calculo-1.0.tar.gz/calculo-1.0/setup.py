from setuptools import setup

setup(
    name="calculo",
    version="1.0",
    description="paquete con potencia, redondeo, suma, resta, multiplicación y división",
    author="clonbg",
    author_email="clonbg@gmail.com",
    url="archgnu.wordpress.com",
    packages=["calculos","calculos"]
)