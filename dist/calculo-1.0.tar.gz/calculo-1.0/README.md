# Curso_python_pildoras_informaticas

- Video 9 min 11:30
- Video 10
- Video 11
- Video 16
- Vídeo 20
- Vídeo 24
- Vídeo 27
- Vídeo 31
- Vídeo 32
- Video 34

## Orden

1. primeras_funciones
2. listas
3. tuplas
4. diccionarios
5. condicionalesIfElse
6. bucleFor
7. bucleWhile
8. buclesContPassElse
9. generadores
10. excepciones, excepciones2 y excepciones3
11. claseCoche (encapsulación)
12. herencia
