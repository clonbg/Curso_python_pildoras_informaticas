def sumar(num1,num2):
    print("El resultado de la suma es: ",num1+num2)

def restar(num1,num2):
    print("El resultado de la resta es: ",num1-num2)

def multiplicar(num1,num2):
    print("El resultado de la multiplicación es: ",num1*num2)

def dividir(num1,num2):
    print("El resultado de la division es: ",num1/num2)

def redondear(num):
    print("El número redondeado es: ",round(num))

def potencia(num1,num2):
    print(num1," elevado a ",num2," es igual a: ", num1**num2)